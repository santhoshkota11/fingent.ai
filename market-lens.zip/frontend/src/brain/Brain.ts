import {
  CheckHealthData,
  GetAllStocksData,
  QueryStockData,
  QueryStockError,
  StockQueryRequest,
} from "./data-contracts";
import { ContentType, HttpClient, RequestParams } from "./http-client";

export class Brain<SecurityDataType = unknown> extends HttpClient<SecurityDataType> {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   *
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  check_health = (params: RequestParams = {}) =>
    this.request<CheckHealthData, any>({
      path: `/_healthz`,
      method: "GET",
      ...params,
    });

  /**
   * No description
   *
   * @tags dbtn/module:stock_analysis
   * @name query_stock
   * @summary Query Stock
   * @request POST:/routes/query-stock
   */
  query_stock = (data: StockQueryRequest, params: RequestParams = {}) =>
    this.request<QueryStockData, QueryStockError>({
      path: `/routes/query-stock`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * No description
   *
   * @tags dbtn/module:stock_analysis
   * @name get_all_stocks
   * @summary Get All Stocks
   * @request GET:/routes/all-stocks
   */
  get_all_stocks = (params: RequestParams = {}) =>
    this.request<GetAllStocksData, any>({
      path: `/routes/all-stocks`,
      method: "GET",
      ...params,
    });
}

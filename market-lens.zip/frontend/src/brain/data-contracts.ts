/** AllStocksResponse */
export interface AllStocksResponse {
  /** Predictions */
  predictions: object[];
}

/** HTTPValidationError */
export interface HTTPValidationError {
  /** Detail */
  detail?: ValidationError[];
}

/** HealthResponse */
export interface HealthResponse {
  /** Status */
  status: string;
}

/** StockQueryRequest */
export interface StockQueryRequest {
  /** Symbol */
  symbol: string;
  /** Query */
  query?: string | null;
  /**
   * Live
   * @default true
   */
  live?: boolean;
}

/** StockQueryResponse */
export interface StockQueryResponse {
  /** Report */
  report: string;
  /** Plot Image */
  plot_image?: string | null;
}

/** ValidationError */
export interface ValidationError {
  /** Location */
  loc: (string | number)[];
  /** Message */
  msg: string;
  /** Error Type */
  type: string;
}

export type CheckHealthData = HealthResponse;

export type QueryStockData = StockQueryResponse;

export type QueryStockError = HTTPValidationError;

export type GetAllStocksData = AllStocksResponse;

import { CheckHealthData, GetAllStocksData, QueryStockData, StockQueryRequest } from "./data-contracts";

export namespace Brain {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  export namespace check_health {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckHealthData;
  }

  /**
   * No description
   * @tags dbtn/module:stock_analysis
   * @name query_stock
   * @summary Query Stock
   * @request POST:/routes/query-stock
   */
  export namespace query_stock {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = StockQueryRequest;
    export type RequestHeaders = {};
    export type ResponseBody = QueryStockData;
  }

  /**
   * No description
   * @tags dbtn/module:stock_analysis
   * @name get_all_stocks
   * @summary Get All Stocks
   * @request GET:/routes/all-stocks
   */
  export namespace get_all_stocks {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAllStocksData;
  }
}

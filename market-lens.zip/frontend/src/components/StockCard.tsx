import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./Card";
import { StockPrediction } from "../utils/types";
import { getTrend, getTrendColor, formatCurrency, formatPercentage } from "../utils/helpers";

interface StockCardProps {
  stock: StockPrediction;
  onClick?: () => void;
}

export function StockCard({ stock, onClick }: StockCardProps) {
  const priceDifference = stock.latest_price - stock.predicted_short_term;
  const percentageChange = (priceDifference / stock.latest_price) * 100;
  const trend = getTrend(stock.latest_price, stock.predicted_short_term);
  const trendColor = getTrendColor(trend);

  return (
    <Card 
      className="bg-gray-800 border-gray-700 hover:bg-gray-750 cursor-pointer transition-all duration-200 overflow-hidden"
      onClick={onClick}
    >
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">{stock.symbol}</CardTitle>
        <div className={`px-2 py-1 rounded text-xs font-semibold ${stock.recommendation === 'buy' ? 'bg-green-900/50 text-green-400' : stock.recommendation === 'sell' ? 'bg-red-900/50 text-red-400' : 'bg-yellow-900/50 text-yellow-400'}`}>
          {stock.recommendation.toUpperCase()}
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between items-baseline">
          <div className="text-2xl font-bold">
            {formatCurrency(stock.latest_price)}
          </div>
          <div className={`flex items-center ${trendColor}`}>
            {trend === 'up' ? (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12 13a1 1 0 100 2h5a1 1 0 001-1v-5a1 1 0 10-2 0v2.586l-4.293-4.293a1 1 0 00-1.414 0L8 9.586l-4.293-4.293a1 1 0 00-1.414 1.414l5 5a1 1 0 001.414 0L11 9.414 14.586 13H12z" clipRule="evenodd" />
              </svg>
            )}
            <span className="ml-1">{formatPercentage(percentageChange / 100)}</span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-2 mt-4 text-sm">
          <div className="text-gray-400">Today's High</div>
          <div className="text-right">{formatCurrency(stock.todays_high)}</div>
          
          <div className="text-gray-400">Today's Low</div>
          <div className="text-right">{formatCurrency(stock.todays_low)}</div>

          <div className="text-gray-400">RSI</div>
          <div className="text-right">{stock.rsi.toFixed(2)}</div>
          
          <div className="text-gray-400">Outlook</div>
          <div className="text-right">{stock.outlook}</div>
        </div>
        
        <div className="mt-4 pt-4 border-t border-gray-700">
          <div className="flex justify-between">
            <div className="text-xs text-gray-400">Short-term Prediction</div>
            <div className="text-xs">{formatCurrency(stock.predicted_short_term)}</div>
          </div>
          <div className="flex justify-between mt-1">
            <div className="text-xs text-gray-400">Medium-term Prediction</div>
            <div className="text-xs">{formatCurrency(stock.predicted_medium_term)}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

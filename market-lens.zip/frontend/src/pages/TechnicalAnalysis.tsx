import React, { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Layout } from "components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "components/Card";
import { SearchBar } from "components/SearchBar";
import { useStore } from "utils/store";
import { StockPrediction, StockQueryResponse } from "utils/types";
import { formatCurrency, getTrendColor } from "utils/helpers";
import brain from "brain";

export default function TechnicalAnalysis() {
  const navigate = useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const querySymbol = queryParams.get("symbol");
  
  const [stocks, setStocks] = useState<StockPrediction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedStock, setSelectedStock] = useState<StockPrediction | null>(null);
  const [stockReport, setStockReport] = useState<StockQueryResponse | null>(null);
  const [isReportLoading, setIsReportLoading] = useState(false);
  const searchQuery = useStore((state) => state.searchQuery);
  const setSearchQuery = useStore((state) => state.setSearchQuery);
  const setCurrentStock = useStore((state) => state.setCurrentStock);

  useEffect(() => {
    async function fetchStocks() {
      try {
        setIsLoading(true);
        const response = await brain.get_all_stocks();
        const data = await response.json();
        setStocks(data.predictions || []);
        setError(null);
        
        // If a symbol is provided in the URL, select it
        if (querySymbol) {
          const stock = data.predictions.find(
            (s: StockPrediction) => s.symbol === querySymbol
          );
          if (stock) {
            setSelectedStock(stock);
            fetchStockReport(querySymbol);
          }
        } else if (data.predictions.length > 0) {
          // Otherwise, select the first stock with a recommendation to buy
          const buyStock = data.predictions.find(
            (s: StockPrediction) => s.recommendation.toLowerCase() === "buy"
          );
          setSelectedStock(buyStock || data.predictions[0]);
          if (buyStock) {
            fetchStockReport(buyStock.symbol);
          } else if (data.predictions.length > 0) {
            fetchStockReport(data.predictions[0].symbol);
          }
        }
      } catch (err) {
        console.error("Error fetching stocks:", err);
        setError("Failed to load stock data. Please try again later.");
      } finally {
        setIsLoading(false);
      }
    }

    fetchStocks();
  }, [querySymbol]);

  const fetchStockReport = async (symbol: string) => {
    if (!symbol) return;
    
    try {
      setIsReportLoading(true);
      // Request analysis with plot
      const response = await brain.query_stock({ symbol, query: "plot", live: true });
      const data = await response.json();
      setStockReport(data);
    } catch (err) {
      console.error("Error fetching stock report:", err);
      setError("Failed to generate stock report. Please try again later.");
    } finally {
      setIsReportLoading(false);
    }
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleStockSelect = (stock: StockPrediction) => {
    setSelectedStock(stock);
    setCurrentStock(stock.symbol);
    fetchStockReport(stock.symbol);
    // Update URL without navigating
    const newUrl = `${location.pathname}?symbol=${stock.symbol}`;
    window.history.pushState({ path: newUrl }, '', newUrl);
  };

  // Filter stocks based on search query
  const filteredStocks = searchQuery.trim() !== ""
    ? stocks.filter(stock => stock.symbol.toLowerCase().includes(searchQuery.toLowerCase()))
    : stocks;

  const getTechnicalIndicatorClass = (value: number, type: 'rsi' | 'macd') => {
    if (type === 'rsi') {
      if (value > 70) return "text-red-500";
      if (value < 30) return "text-green-500";
      return "text-yellow-500";
    } else { // macd
      return value > 0 ? "text-green-500" : "text-red-500";
    }
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="bg-red-900/20 border border-red-800 text-red-300 p-4 rounded-md">
          {error}
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Sidebar - Stock List */}
        <div className="lg:col-span-1">
          <div className="mb-4">
            <SearchBar onSearch={handleSearch} initialValue={searchQuery} />
          </div>
          
          <Card className="bg-gray-800 border-gray-700 overflow-hidden">
            <CardHeader>
              <CardTitle className="text-lg">Stocks</CardTitle>
            </CardHeader>
            <CardContent className="p-0 max-h-[600px] overflow-y-auto">
              <ul className="divide-y divide-gray-700">
                {filteredStocks.map(stock => (
                  <li 
                    key={stock.symbol}
                    className={`hover:bg-gray-750 cursor-pointer ${selectedStock?.symbol === stock.symbol ? 'bg-gray-750 border-l-4 border-blue-500' : ''}`}
                    onClick={() => handleStockSelect(stock)}
                  >
                    <div className="px-4 py-3">
                      <div className="flex justify-between items-center">
                        <div className="font-medium">{stock.symbol}</div>
                        <div className={getTrendColor(stock.latest_price > stock.predicted_short_term ? 'down' : 'up')}>
                          {formatCurrency(stock.latest_price)}
                        </div>
                      </div>
                      <div className="flex justify-between items-center mt-1 text-xs text-gray-400">
                        <div>RSI: <span className={getTechnicalIndicatorClass(stock.rsi, 'rsi')}>{stock.rsi.toFixed(1)}</span></div>
                        <div className={`px-1.5 py-0.5 rounded text-xs ${stock.recommendation === 'buy' ? 'bg-green-900/50 text-green-400' : stock.recommendation === 'sell' ? 'bg-red-900/50 text-red-400' : 'bg-yellow-900/50 text-yellow-400'}`}>
                          {stock.recommendation.toUpperCase()}
                        </div>
                      </div>
                    </div>
                  </li>
                ))}

                {filteredStocks.length === 0 && (
                  <li className="px-4 py-3 text-gray-400 text-center">
                    No stocks found matching your search
                  </li>
                )}
              </ul>
            </CardContent>
          </Card>
        </div>
        
        {/* Right Content - Technical Analysis */}
        <div className="lg:col-span-3">
          {selectedStock ? (
            <div className="space-y-6">
              {/* Stock Header */}
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-2xl font-bold">{selectedStock.symbol}</h2>
                  <div className="text-gray-400 text-sm">Technical Analysis</div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold">{formatCurrency(selectedStock.latest_price)}</div>
                  <div className={`text-sm ${getTrendColor(selectedStock.outlook.toLowerCase() === 'bullish' ? 'up' : 'down')}`}>
                    {selectedStock.outlook}
                  </div>
                </div>
              </div>
              
              {/* Chart */}
              <Card className="bg-gray-800 border-gray-700">
                <CardContent className="p-0 overflow-hidden">
                  {stockReport?.plot_image ? (
                    <img 
                      src={`data:image/png;base64,${stockReport.plot_image}`} 
                      alt={`${selectedStock.symbol} Chart`} 
                      className="w-full h-auto"
                    />
                  ) : (
                    <div className="flex items-center justify-center h-64 bg-gray-850">
                      {isReportLoading ? (
                        <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-blue-500"></div>
                      ) : (
                        <p className="text-gray-400">Chart not available</p>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
              
              {/* Technical Indicators */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-gray-400">RSI (14)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`text-2xl font-bold ${getTechnicalIndicatorClass(selectedStock.rsi, 'rsi')}`}>
                      {selectedStock.rsi.toFixed(2)}
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2.5 mt-2">
                      <div 
                        className={`h-2.5 rounded-full ${selectedStock.rsi > 70 ? 'bg-red-500' : selectedStock.rsi < 30 ? 'bg-green-500' : 'bg-yellow-500'}`} 
                        style={{ width: `${Math.min(selectedStock.rsi, 100)}%` }}
                      ></div>
                    </div>
                    <div className="flex justify-between text-xs text-gray-400 mt-1">
                      <span>0</span>
                      <span>30</span>
                      <span>70</span>
                      <span>100</span>
                    </div>
                    <div className="mt-2 text-xs text-gray-400">
                      {selectedStock.rsi > 70 ? 
                        "Overbought - Potential reversal or correction" : 
                        selectedStock.rsi < 30 ? 
                        "Oversold - Potential bullish reversal" : 
                        "Neutral"}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-gray-400">Moving Averages</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{formatCurrency(selectedStock.sma_20)}</div>
                    <div className={`text-sm ${getTrendColor(selectedStock.sma_20 > selectedStock.latest_price ? 'down' : 'up')}`}>
                      {selectedStock.sma_20 > selectedStock.latest_price ? "Below MA" : "Above MA"}
                    </div>
                    <div className="mt-2 text-xs text-gray-400">
                      Price is {Math.abs(((selectedStock.latest_price / selectedStock.sma_20) - 1) * 100).toFixed(2)}% 
                      {selectedStock.latest_price > selectedStock.sma_20 ? "above" : "below"} the 20-day Moving Average
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-gray-400">Recommendation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className={`text-2xl font-bold ${selectedStock.recommendation === 'buy' ? 'text-green-500' : selectedStock.recommendation === 'sell' ? 'text-red-500' : 'text-yellow-500'}`}>
                      {selectedStock.recommendation.toUpperCase()}
                    </div>
                    <div className="text-sm text-gray-300">
                      Confidence: {selectedStock.confidence}
                    </div>
                    <div className="mt-2 text-xs text-gray-400">
                      {selectedStock.recommendation === 'buy' ? 
                        "Technical indicators suggest a buying opportunity" : 
                        selectedStock.recommendation === 'sell' ? 
                        "Technical indicators suggest a selling opportunity" : 
                        "Technical indicators suggest holding the position"}
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Analysis Report */}
              {stockReport?.report && (
                <Card className="bg-gray-800 border-gray-700">
                  <CardHeader>
                    <CardTitle>Detailed Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="prose prose-sm max-w-none prose-invert">
                      {stockReport.report.split('\n').map((paragraph, index) => (
                        <p key={index}>{paragraph}</p>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <div className="text-center p-8">
              <p className="text-gray-400">Select a stock to view technical analysis</p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

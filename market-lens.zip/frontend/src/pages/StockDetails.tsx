import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { Layout } from "components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "components/Card";
import { Button } from "components/Button";
import { StockPrediction, StockQueryResponse } from "utils/types";
import { formatCurrency, getTrendColor, getTrend, getRecommendationColor } from "utils/helpers";
import brain from "brain";

export default function StockDetails() {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const symbol = queryParams.get("symbol");
  
  const [stockData, setStockData] = useState<StockPrediction | null>(null);
  const [stockReport, setStockReport] = useState<StockQueryResponse | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isReportLoading, setIsReportLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!symbol) {
      setError("No stock symbol provided");
      setIsLoading(false);
      return;
    }

    async function fetchStockData() {
      try {
        setIsLoading(true);
        setError(null);
        
        // Get all stocks and find the one we need
        console.log(`Fetching stock data for symbol: ${symbol}`);
        const response = await brain.get_all_stocks();
        if (!response.ok) {
          throw new Error(`API error: ${response.status} ${response.statusText}`);
        }
        
        const data = await response.json();
        console.log(`Received ${data.predictions?.length || 0} predictions`);
        
        if (!data.predictions || !Array.isArray(data.predictions)) {
          throw new Error('Invalid API response format: predictions not found or not an array');
        }
        
        const stock = data.predictions.find(
          (s: StockPrediction) => s?.symbol === symbol
        );

        if (stock) {
          console.log(`Found stock data for ${symbol}:`, stock);
          setStockData(stock);
          setError(null);
        } else {
          console.warn(`No data found for stock symbol ${symbol}`);
          setError(`No data found for stock symbol ${symbol}`);
        }
      } catch (err) {
        console.error("Error fetching stock data:", err);
        setError("Failed to load stock data. Please try again later.");
      } finally {
        setIsLoading(false);
      }
    }

    fetchStockData();
  }, [symbol]);

  const fetchStockReport = async () => {
    if (!symbol) return;
    
    try {
      setIsReportLoading(true);
      setError(null);
      console.log(`Generating analysis for ${symbol} with plot`);
      
      const response = await brain.query_stock({ symbol, live: true, query: "plot" });
      if (!response.ok) {
        throw new Error(`API error: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
      console.log(`Received stock report with plot: ${!!data.plot_image}`);
      setStockReport(data);
    } catch (err) {
      console.error("Error fetching stock report:", err);
      setError("Failed to generate stock report. Please try again later.");
    } finally {
      setIsReportLoading(false);
    }
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="bg-red-900/20 border border-red-800 text-red-300 p-4 rounded-md">
          {error}
        </div>
      </Layout>
    );
  }

  if (!stockData) {
    return (
      <Layout>
        <div>No stock data available</div>
      </Layout>
    );
  }

  const priceDifference = stockData.latest_price - stockData.predicted_short_term;
  const percentageChange = (priceDifference / stockData.latest_price) * 100;
  const trend = getTrend(stockData.latest_price, stockData.predicted_short_term);
  const trendColor = getTrendColor(trend);
  const recommendationColor = getRecommendationColor(stockData.recommendation);

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Stock Info */}
        <div className="lg:col-span-1 space-y-6">
          {/* Stock Price Card */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-2xl">{stockData.symbol}</CardTitle>
                  <p className="text-gray-400 text-sm">Current Price</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-sm font-semibold ${recommendationColor} bg-opacity-20`}>
                  {stockData.recommendation.toUpperCase()}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline justify-between">
                <div className="text-3xl font-bold">
                  {formatCurrency(stockData.latest_price)}
                </div>
                <div className={`flex items-center ${trendColor}`}>
                  {trend === 'up' ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M12 7a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0V8.414l-4.293 4.293a1 1 0 01-1.414 0L8 10.414l-4.293 4.293a1 1 0 01-1.414-1.414l5-5a1 1 0 011.414 0L11 10.586 14.586 7H12z" clipRule="evenodd" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M12 13a1 1 0 100 2h5a1 1 0 001-1v-5a1 1 0 10-2 0v2.586l-4.293-4.293a1 1 0 00-1.414 0L8 9.586l-4.293-4.293a1 1 0 00-1.414 1.414l5 5a1 1 0 001.414 0L11 9.414 14.586 13H12z" clipRule="evenodd" />
                    </svg>
                  )}
                  {Math.abs(percentageChange).toFixed(2)}%
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-y-2 mt-6">
                <div className="text-gray-400">Today's Range</div>
                <div className="text-right">
                  {formatCurrency(stockData.todays_low)} - {formatCurrency(stockData.todays_high)}
                </div>
                
                <div className="text-gray-400">RSI (14)</div>
                <div className="text-right">{stockData.rsi.toFixed(2)}</div>
                
                <div className="text-gray-400">SMA (20)</div>
                <div className="text-right">{formatCurrency(stockData.sma_20)}</div>
                
                <div className="text-gray-400">Sentiment</div>
                <div className="text-right">{stockData.sentiment}</div>
                
                <div className="text-gray-400">Confidence</div>
                <div className="text-right">{stockData.confidence}</div>
              </div>
            </CardContent>
          </Card>
          
          {/* Price Predictions Card */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle>Price Predictions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Short-term (1-7 days)</span>
                    <span className="text-sm">{formatCurrency(stockData.predicted_short_term)}</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2.5">
                    <div 
                      className={`h-2.5 rounded-full ${stockData.predicted_short_term > stockData.latest_price ? 'bg-green-600' : 'bg-red-600'}`} 
                      style={{ width: `${Math.min(Math.max(stockData.predicted_short_term / stockData.latest_price * 100, 0), 100)}%` }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Medium-term (1-3 months)</span>
                    <span className="text-sm">{formatCurrency(stockData.predicted_medium_term)}</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2.5">
                    <div 
                      className={`h-2.5 rounded-full ${stockData.predicted_medium_term > stockData.latest_price ? 'bg-green-600' : 'bg-red-600'}`} 
                      style={{ width: `${Math.min(Math.max(stockData.predicted_medium_term / stockData.latest_price * 100, 0), 100)}%` }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-gray-400">Long-term (6+ months)</span>
                    <span className="text-sm">{formatCurrency(stockData.predicted_long_term)}</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2.5">
                    <div 
                      className={`h-2.5 rounded-full ${stockData.predicted_long_term > stockData.latest_price ? 'bg-green-600' : 'bg-red-600'}`} 
                      style={{ width: `${Math.min(Math.max(stockData.predicted_long_term / stockData.latest_price * 100, 0), 100)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Right Column - Charts & Analysis */}
        <div className="lg:col-span-2 space-y-6">
          {/* Chart Card */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Stock Chart</CardTitle>
                <Button
                  variant="outline" 
                  onClick={fetchStockReport}
                  disabled={isReportLoading}
                >
                  {isReportLoading ? "Generating..." : "Generate Analysis"}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {stockReport?.plot_image ? (
                <div className="rounded-lg overflow-hidden border border-gray-700">
                  <img 
                    src={`data:image/png;base64,${stockReport.plot_image}`} 
                    alt={`${symbol} Chart`} 
                    className="w-full h-auto"
                    onError={(e) => {
                      console.error('Error loading chart image');
                      // Fallback to a message if image fails to load
                      e.currentTarget.outerHTML = '<div class="p-4 text-gray-400">Error loading chart. Please try again.</div>';
                    }}
                  />
                </div>
              ) : (
                <div className="flex items-center justify-center h-64 bg-gray-850 rounded-lg border border-gray-700">
                  <p className="text-gray-400">
                    {isReportLoading 
                      ? "Generating chart..." 
                      : "Click 'Generate Analysis' to view stock chart and analysis report"}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Analysis Report Card */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle>Analysis Report</CardTitle>
            </CardHeader>
            <CardContent>
              {stockReport?.report ? (
                <div className="prose prose-sm max-w-none prose-invert">
                  {stockReport.report.split('\n').map((paragraph, index) => (
                    <p key={index}>{paragraph}</p>
                  ))}
                </div>
              ) : (
                <div className="flex items-center justify-center h-64 bg-gray-850 rounded-lg border border-gray-700">
                  <p className="text-gray-400">
                    {isReportLoading 
                      ? "Generating analysis report..." 
                      : "Click 'Generate Analysis' to view detailed analysis report"}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}

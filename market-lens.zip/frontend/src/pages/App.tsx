import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "components/Button";
import { Card, CardContent, CardHeader, CardTitle } from "components/Card";
import { useStore } from "utils/store";

export default function App() {
  const navigate = useNavigate();
  const setTheme = useStore((state) => state.setTheme);

  // Ensure dark theme is applied
  useEffect(() => {
    setTheme('dark');
  }, [setTheme]);

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-gray-900 to-gray-950 text-white">
      <header className="p-6 border-b border-gray-800">
        <div className="container mx-auto">
          <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-600">MarketLens</h1>
          <p className="text-gray-400 mt-2">Professional Stock Analysis & Insights</p>
        </div>
      </header>

      <main className="flex-1 container mx-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
          <div className="flex flex-col justify-center space-y-6">
            <h2 className="text-4xl font-bold">Advanced Stock Analysis Powered by AI</h2>
            <p className="text-xl text-gray-300">
              MarketLens provides professional-grade stock insights, technical analysis, and price predictions to help you make informed trading decisions.
            </p>
            <div className="space-y-3">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center mr-3">1</div>
                <p className="text-gray-200">Real-time stock data and technical indicators</p>
              </div>
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center mr-3">2</div>
                <p className="text-gray-200">AI-powered price predictions and sentiment analysis</p>
              </div>
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center mr-3">3</div>
                <p className="text-gray-200">Options trading strategies and recommendations</p>
              </div>
            </div>
            <div className="pt-4">
              <Button 
                onClick={() => navigate('/dashboard')} 
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 h-auto text-lg"
              >
                Go to Dashboard →
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card className="bg-gray-800 border-gray-700 hover:border-blue-500 transition-all duration-300">
              <CardHeader>
                <CardTitle className="text-gray-100">Technical Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">Get in-depth technical indicators including RSI, MACD, Bollinger Bands, and more.</p>
              </CardContent>
            </Card>
            <Card className="bg-gray-800 border-gray-700 hover:border-purple-500 transition-all duration-300">
              <CardHeader>
                <CardTitle className="text-gray-100">AI Predictions</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">View short, medium, and long-term price predictions powered by machine learning.</p>
              </CardContent>
            </Card>
            <Card className="bg-gray-800 border-gray-700 hover:border-green-500 transition-all duration-300">
              <CardHeader>
                <CardTitle className="text-gray-100">Options Trading</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">Get tailored options trading strategies based on market outlook and volatility.</p>
              </CardContent>
            </Card>
            <Card className="bg-gray-800 border-gray-700 hover:border-yellow-500 transition-all duration-300">
              <CardHeader>
                <CardTitle className="text-gray-100">Market Insights</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">Stay updated with market trends, correlation analysis, and sentiment indicators.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <footer className="border-t border-gray-800 py-6">
        <div className="container mx-auto px-6 text-center text-gray-500">
          <p>© 2025 MarketLens. Professional Stock Analysis Platform.</p>
        </div>
      </footer>
    </div>
  );
}

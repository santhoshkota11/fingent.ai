import React, { useEffect, useState } from "react";
import { Layout } from "components/Layout";
import { StockCard } from "components/StockCard";
import { Card, CardContent, CardHeader, CardTitle } from "components/Card";
import { useNavigate } from "react-router-dom";
import { SearchBar } from "components/SearchBar";
import { useStore } from "utils/store";
import { StockPrediction } from "utils/types";
import { formatCurrency } from "utils/helpers";
import brain from "brain";

export default function Dashboard() {
  const navigate = useNavigate();
  const [stocks, setStocks] = useState<StockPrediction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const searchQuery = useStore((state) => state.searchQuery);
  const setSearchQuery = useStore((state) => state.setSearchQuery);
  const setCurrentStock = useStore((state) => state.setCurrentStock);

  useEffect(() => {
    async function fetchStocks() {
      try {
        setIsLoading(true);
        const response = await brain.get_all_stocks();
        const data = await response.json();
        setStocks(data.predictions || []);
        setError(null);
      } catch (err) {
        console.error("Error fetching stocks:", err);
        setError("Failed to load stock data. Please try again later.");
      } finally {
        setIsLoading(false);
      }
    }

    fetchStocks();
  }, []);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleStockClick = (symbol: string) => {
    setCurrentStock(symbol);
    navigate(`/stock-details?symbol=${symbol}`);
  };

  // Filter stocks based on search query
  const filteredStocks = searchQuery.trim() !== ""
    ? stocks.filter(stock => stock.symbol.toLowerCase().includes(searchQuery.toLowerCase()))
    : stocks;

  // Calculate market statistics
  const upStocks = stocks.filter(stock => stock.latest_price > stock.predicted_short_term).length;
  const downStocks = stocks.filter(stock => stock.latest_price < stock.predicted_short_term).length;
  const neutralStocks = stocks.length - upStocks - downStocks;
  
  // Get stocks with buy/sell recommendations
  const buyStocks = stocks.filter(stock => stock.recommendation.toLowerCase() === 'buy');
  const sellStocks = stocks.filter(stock => stock.recommendation.toLowerCase() === 'sell');

  return (
    <Layout>
      <div className="mb-6">
        <SearchBar onSearch={handleSearch} initialValue={searchQuery} />
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : error ? (
        <div className="bg-red-900/20 border border-red-800 text-red-300 p-4 rounded-md">
          {error}
        </div>
      ) : (
        <>
          {/* Market Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-gray-400">Market Sentiment</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between">
                  <div>
                    <div className="text-2xl font-bold">
                      {stocks.length > 0 ? 
                        (upStocks / stocks.length * 100).toFixed(1) + "%" : 
                        "N/A"}
                    </div>
                    <div className="text-xs text-gray-400 mt-1">Bullish</div>
                  </div>
                  <div className="flex h-16">
                    <div className="w-4 bg-green-500 rounded-sm mx-0.5" style={{ height: `${upStocks/stocks.length*100}%` }}></div>
                    <div className="w-4 bg-yellow-500 rounded-sm mx-0.5" style={{ height: `${neutralStocks/stocks.length*100}%` }}></div>
                    <div className="w-4 bg-red-500 rounded-sm mx-0.5" style={{ height: `${downStocks/stocks.length*100}%` }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-gray-400">Top Gainer</CardTitle>
              </CardHeader>
              <CardContent>
                {stocks.length > 0 ? (
                  <>
                    <div className="text-lg font-bold">
                      {stocks.sort((a, b) => 
                        (b.latest_price - b.predicted_short_term) / b.predicted_short_term - 
                        (a.latest_price - a.predicted_short_term) / a.predicted_short_term
                      )[0]?.symbol || "N/A"}
                    </div>
                    <div className="text-2xl font-bold text-green-500 mt-1">
                      +{stocks.length > 0 ? 
                        (((stocks.sort((a, b) => 
                          (b.latest_price - b.predicted_short_term) / b.predicted_short_term - 
                          (a.latest_price - a.predicted_short_term) / a.predicted_short_term
                        )[0]?.latest_price || 0) - 
                        (stocks.sort((a, b) => 
                          (b.latest_price - b.predicted_short_term) / b.predicted_short_term - 
                          (a.latest_price - a.predicted_short_term) / a.predicted_short_term
                        )[0]?.predicted_short_term || 0)) / 
                        (stocks.sort((a, b) => 
                          (b.latest_price - b.predicted_short_term) / b.predicted_short_term - 
                          (a.latest_price - a.predicted_short_term) / a.predicted_short_term
                        )[0]?.predicted_short_term || 1) * 100).toFixed(2) : 
                        "0.00"}%
                    </div>
                  </>
                ) : (
                  <div className="text-gray-400">No data available</div>
                )}
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-gray-400">Buy Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between">
                  <div>
                    <div className="text-2xl font-bold">
                      {buyStocks.length}
                    </div>
                    <div className="text-xs text-gray-400 mt-1">Stocks</div>
                  </div>
                  <div className="text-green-500 text-sm font-medium">
                    {stocks.length > 0 ? 
                      ((buyStocks.length / stocks.length) * 100).toFixed(1) + "%" : 
                      "0%"}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-gray-400">Sell Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end justify-between">
                  <div>
                    <div className="text-2xl font-bold">
                      {sellStocks.length}
                    </div>
                    <div className="text-xs text-gray-400 mt-1">Stocks</div>
                  </div>
                  <div className="text-red-500 text-sm font-medium">
                    {stocks.length > 0 ? 
                      ((sellStocks.length / stocks.length) * 100).toFixed(1) + "%" : 
                      "0%"}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Top Stocks Section */}
          <h2 className="text-xl font-semibold mb-4">Top Stocks</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {filteredStocks.slice(0, 6).map((stock) => (
              <StockCard
                key={stock.symbol}
                stock={stock}
                onClick={() => handleStockClick(stock.symbol)}
              />
            ))}
          </div>

          {/* Buy Recommendations */}
          <h2 className="text-xl font-semibold mb-4">Recommended Buys</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {buyStocks.slice(0, 3).map((stock) => (
              <StockCard
                key={stock.symbol}
                stock={stock}
                onClick={() => handleStockClick(stock.symbol)}
              />
            ))}
          </div>
        </>
      )}
    </Layout>
  );
}

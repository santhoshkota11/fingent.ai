import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "components/Layout";
import { StockCard } from "components/StockCard";
import { Card, CardContent, CardHeader, CardTitle } from "components/Card";
import { useStore } from "utils/store";
import { StockPrediction } from "utils/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { sortStocks, formatCurrency } from "utils/helpers";
import brain from "brain";

export default function MarketOverview() {
  const navigate = useNavigate();
  const [stocks, setStocks] = useState<StockPrediction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const setCurrentStock = useStore((state) => state.setCurrentStock);

  useEffect(() => {
    async function fetchStocks() {
      try {
        setIsLoading(true);
        const response = await brain.get_all_stocks();
        const data = await response.json();
        setStocks(data.predictions || []);
        setError(null);
      } catch (err) {
        console.error("Error fetching stocks:", err);
        setError("Failed to load market data. Please try again later.");
      } finally {
        setIsLoading(false);
      }
    }

    fetchStocks();
  }, []);

  const handleStockClick = (symbol: string) => {
    setCurrentStock(symbol);
    navigate(`/stock-details?symbol=${symbol}`);
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="bg-red-900/20 border border-red-800 text-red-300 p-4 rounded-md">
          {error}
        </div>
      </Layout>
    );
  }

  // Calculate market statistics
  const upStocks = stocks.filter(stock => stock.latest_price > stock.predicted_short_term).length;
  const downStocks = stocks.filter(stock => stock.latest_price < stock.predicted_short_term).length;
  const neutralStocks = stocks.length - upStocks - downStocks;
  const marketSentiment = upStocks > downStocks ? "Bullish" : upStocks < downStocks ? "Bearish" : "Neutral";
  
  // Sort stocks for different categories
  const topGainers = sortStocks(stocks, "latest_price", "desc").slice(0, 3);
  const topLosers = sortStocks(stocks, "latest_price", "asc").slice(0, 3);
  const topRecommendations = stocks.filter(stock => stock.recommendation.toLowerCase() === "buy").slice(0, 3);

  return (
    <Layout>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Market Sentiment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{marketSentiment}</div>
            <div className="flex items-center mt-2">
              <div className="flex-1 mr-2">
                <div className="h-2 bg-gray-700 rounded-full">
                  <div 
                    className="h-2 bg-green-500 rounded-full" 
                    style={{ width: `${(upStocks / stocks.length) * 100}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-400 mt-1">Bullish: {upStocks}</div>
              </div>
              <div className="flex-1 mx-2">
                <div className="h-2 bg-gray-700 rounded-full">
                  <div 
                    className="h-2 bg-yellow-500 rounded-full" 
                    style={{ width: `${(neutralStocks / stocks.length) * 100}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-400 mt-1">Neutral: {neutralStocks}</div>
              </div>
              <div className="flex-1 ml-2">
                <div className="h-2 bg-gray-700 rounded-full">
                  <div 
                    className="h-2 bg-red-500 rounded-full" 
                    style={{ width: `${(downStocks / stocks.length) * 100}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-400 mt-1">Bearish: {downStocks}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Average RSI</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(stocks.reduce((sum, stock) => sum + stock.rsi, 0) / stocks.length).toFixed(2)}
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2.5 mt-2">
              <div 
                className="bg-blue-600 h-2.5 rounded-full" 
                style={{ width: `${(stocks.reduce((sum, stock) => sum + stock.rsi, 0) / stocks.length) / 100 * 100}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-xs text-gray-400 mt-1">
              <span>0</span>
              <span>50</span>
              <span>100</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Buy vs Sell Ratio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(stocks.filter(s => s.recommendation.toLowerCase() === "buy").length / 
                (stocks.filter(s => s.recommendation.toLowerCase() === "sell").length || 1)).toFixed(2)}
            </div>
            <div className="flex items-center mt-2">
              <div className="flex-1 mr-2">
                <div className="h-2 bg-gray-700 rounded-full">
                  <div 
                    className="h-2 bg-green-500 rounded-full" 
                    style={{ width: `${(stocks.filter(s => s.recommendation.toLowerCase() === "buy").length / stocks.length) * 100}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-400 mt-1">Buy: {stocks.filter(s => s.recommendation.toLowerCase() === "buy").length}</div>
              </div>
              <div className="flex-1 ml-2">
                <div className="h-2 bg-gray-700 rounded-full">
                  <div 
                    className="h-2 bg-red-500 rounded-full" 
                    style={{ width: `${(stocks.filter(s => s.recommendation.toLowerCase() === "sell").length / stocks.length) * 100}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-400 mt-1">Sell: {stocks.filter(s => s.recommendation.toLowerCase() === "sell").length}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Market Outlook</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stocks.filter(s => s.outlook.toLowerCase() === "bullish").length > 
               stocks.filter(s => s.outlook.toLowerCase() === "bearish").length ? "Bullish" : "Bearish"}
            </div>
            <div className="flex items-center mt-2">
              <div className="flex-1 mr-2">
                <div className="h-2 bg-gray-700 rounded-full">
                  <div 
                    className="h-2 bg-green-500 rounded-full" 
                    style={{ width: `${(stocks.filter(s => s.outlook.toLowerCase() === "bullish").length / stocks.length) * 100}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-400 mt-1">Bullish: {stocks.filter(s => s.outlook.toLowerCase() === "bullish").length}</div>
              </div>
              <div className="flex-1 ml-2">
                <div className="h-2 bg-gray-700 rounded-full">
                  <div 
                    className="h-2 bg-red-500 rounded-full" 
                    style={{ width: `${(stocks.filter(s => s.outlook.toLowerCase() === "bearish").length / stocks.length) * 100}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-400 mt-1">Bearish: {stocks.filter(s => s.outlook.toLowerCase() === "bearish").length}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Gainers Section */}
      <h2 className="text-xl font-semibold mb-4">Top Gainers</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {topGainers.map((stock) => (
          <StockCard
            key={stock.symbol}
            stock={stock}
            onClick={() => handleStockClick(stock.symbol)}
          />
        ))}
      </div>

      {/* Top Losers Section */}
      <h2 className="text-xl font-semibold mb-4">Top Losers</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {topLosers.map((stock) => (
          <StockCard
            key={stock.symbol}
            stock={stock}
            onClick={() => handleStockClick(stock.symbol)}
          />
        ))}
      </div>

      {/* Top Recommendations Section */}
      <h2 className="text-xl font-semibold mb-4">Top Recommendations</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {topRecommendations.map((stock) => (
          <StockCard
            key={stock.symbol}
            stock={stock}
            onClick={() => handleStockClick(stock.symbol)}
          />
        ))}
      </div>

      {/* All Stocks Prediction Table */}
      <h2 className="text-xl font-semibold my-8">All Stock Predictions</h2>
      <Card className="bg-gray-800 border-gray-700 overflow-auto">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-gray-800 border-gray-700">
                <TableHead className="text-gray-300">Symbol</TableHead>
                <TableHead className="text-gray-300">Latest (₹)</TableHead>
                <TableHead className="text-gray-300">Today's High (₹)</TableHead>
                <TableHead className="text-gray-300">Today's Low (₹)</TableHead>
                <TableHead className="text-gray-300">Tomorrow (₹)</TableHead>
                <TableHead className="text-gray-300">Short-Term (₹)</TableHead>
                <TableHead className="text-gray-300">Medium-Term (₹)</TableHead>
                <TableHead className="text-gray-300">Long-Term (₹)</TableHead>
                <TableHead className="text-gray-300">SMA 20 (₹)</TableHead>
                <TableHead className="text-gray-300">RSI</TableHead>
                <TableHead className="text-gray-300">Sentiment</TableHead>
                <TableHead className="text-gray-300">Confidence</TableHead>
                <TableHead className="text-gray-300">Recommendation</TableHead>
                <TableHead className="text-gray-300">Outlook</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stocks.map((stock) => (
                <TableRow 
                  key={stock.symbol} 
                  className="hover:bg-gray-700 border-gray-700 cursor-pointer" 
                  onClick={() => handleStockClick(stock.symbol)}
                >
                  <TableCell className="font-medium">{stock.symbol}</TableCell>
                  <TableCell>{formatCurrency(stock.latest_price)}</TableCell>
                  <TableCell>{formatCurrency(stock.todays_high)}</TableCell>
                  <TableCell>{formatCurrency(stock.todays_low)}</TableCell>
                  <TableCell>{formatCurrency(stock.tomorrow_pred)}</TableCell>
                  <TableCell>{formatCurrency(stock.predicted_short_term)}</TableCell>
                  <TableCell>{formatCurrency(stock.predicted_medium_term)}</TableCell>
                  <TableCell>{formatCurrency(stock.predicted_long_term)}</TableCell>
                  <TableCell>{formatCurrency(stock.sma_20)}</TableCell>
                  <TableCell>{stock.rsi.toFixed(2)}</TableCell>
                  <TableCell>{stock.sentiment}</TableCell>
                  <TableCell>{stock.confidence}</TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded text-xs ${stock.recommendation.toLowerCase() === 'buy' ? 'bg-green-900/40 text-green-300' : stock.recommendation.toLowerCase() === 'sell' ? 'bg-red-900/40 text-red-300' : 'bg-gray-700 text-gray-300'}`}>
                      {stock.recommendation}
                    </span>
                  </TableCell>
                  <TableCell>
                    <span className={`px-2 py-1 rounded text-xs ${stock.outlook.toLowerCase() === 'bullish' ? 'bg-green-900/40 text-green-300' : stock.outlook.toLowerCase() === 'bearish' ? 'bg-red-900/40 text-red-300' : 'bg-gray-700 text-gray-300'}`}>
                      {stock.outlook}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </Layout>
  );
}

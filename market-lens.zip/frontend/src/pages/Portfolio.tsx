import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "components/Card";
import { Input } from "components/Input";
import { Button } from "components/Button";
import { useStore } from "utils/store";
import { StockPrediction } from "utils/types";
import { formatCurrency, getTrendColor } from "utils/helpers";
import brain from "brain";

interface PortfolioItem {
  symbol: string;
  shares: number;
  buyPrice: number;
  stockData?: StockPrediction;
}

export default function Portfolio() {
  const navigate = useNavigate();
  const setCurrentStock = useStore((state) => state.setCurrentStock);
  
  // Portfolio state
  const [portfolio, setPortfolio] = useState<PortfolioItem[]>([]);
  const [allStocks, setAllStocks] = useState<StockPrediction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Form state for adding stocks
  const [newSymbol, setNewSymbol] = useState("");
  const [newShares, setNewShares] = useState("1");
  const [newBuyPrice, setNewBuyPrice] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);

  // Load stocks data
  useEffect(() => {
    async function fetchStocks() {
      try {
        setIsLoading(true);
        const response = await brain.get_all_stocks();
        const data = await response.json();
        setAllStocks(data.predictions || []);
        setError(null);
        
        // Initialize sample portfolio for demo purposes
        if (portfolio.length === 0) {
          const samplePortfolio: PortfolioItem[] = [
            { symbol: "RELIANCE.NS", shares: 10, buyPrice: 2400 },
            { symbol: "TCS.NS", shares: 5, buyPrice: 3500 },
            { symbol: "HDFCBANK.NS", shares: 15, buyPrice: 1600 },
          ];
          setPortfolio(samplePortfolio);
        }
      } catch (err) {
        console.error("Error fetching stocks:", err);
        setError("Failed to load stock data. Please try again later.");
      } finally {
        setIsLoading(false);
      }
    }

    fetchStocks();
  }, []);

  // Enrich portfolio with stock data
  const enrichedPortfolio = portfolio.map(item => {
    const stockData = allStocks.find(stock => stock.symbol === item.symbol);
    return {
      ...item,
      stockData
    };
  });

  const handleAddStock = () => {
    if (!newSymbol || !newShares || !newBuyPrice) {
      return;
    }

    const stockExists = allStocks.find(stock => stock.symbol === newSymbol);
    if (!stockExists) {
      alert("Stock symbol not found. Please enter a valid symbol.");
      return;
    }

    const newItem: PortfolioItem = {
      symbol: newSymbol,
      shares: parseInt(newShares),
      buyPrice: parseFloat(newBuyPrice),
    };

    setPortfolio([...portfolio, newItem]);
    setNewSymbol("");
    setNewShares("1");
    setNewBuyPrice("");
    setShowAddForm(false);
  };

  const handleRemoveStock = (index: number) => {
    const updatedPortfolio = [...portfolio];
    updatedPortfolio.splice(index, 1);
    setPortfolio(updatedPortfolio);
  };

  const handleStockClick = (symbol: string) => {
    setCurrentStock(symbol);
    navigate(`/stock-details?symbol=${symbol}`);
  };

  // Calculate portfolio metrics
  const totalInvestment = enrichedPortfolio.reduce(
    (sum, item) => sum + item.shares * item.buyPrice, 0
  );

  const currentValue = enrichedPortfolio.reduce(
    (sum, item) => sum + item.shares * (item.stockData?.latest_price || 0), 0
  );

  const totalGain = currentValue - totalInvestment;
  const totalGainPercentage = (totalGain / totalInvestment) * 100;
  const todaysGain = enrichedPortfolio.reduce(
    (sum, item) => {
      if (!item.stockData) return sum;
      const todayChange = item.stockData.latest_price - item.stockData.todays_low;
      return sum + (todayChange * item.shares);
    }, 0
  );

  // Get buy recommendations not in portfolio
  const buyRecommendations = allStocks
    .filter(stock => 
      stock.recommendation.toLowerCase() === "buy" && 
      !portfolio.some(item => item.symbol === stock.symbol)
    )
    .slice(0, 3);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="bg-red-900/20 border border-red-800 text-red-300 p-4 rounded-md">
          {error}
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      {/* Portfolio Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Portfolio Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(currentValue)}</div>
            <div className={`text-sm ${getTrendColor(totalGain >= 0 ? 'up' : 'down')}`}>
              {totalGain >= 0 ? "+" : ""}{formatCurrency(totalGain)} ({totalGainPercentage.toFixed(2)}%)
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Total Investment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalInvestment)}</div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Today's Gain/Loss</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getTrendColor(todaysGain >= 0 ? 'up' : 'down')}`}>
              {todaysGain >= 0 ? "+" : ""}{formatCurrency(todaysGain)}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Positions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{portfolio.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Portfolio Holdings */}
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Your Holdings</h2>
        <Button onClick={() => setShowAddForm(!showAddForm)}>
          {showAddForm ? "Cancel" : "Add Stock"}
        </Button>
      </div>

      {/* Add Stock Form */}
      {showAddForm && (
        <Card className="bg-gray-800 border-gray-700 mb-6">
          <CardContent className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Stock Symbol</label>
                <Input 
                  value={newSymbol} 
                  onChange={e => setNewSymbol(e.target.value)}
                  placeholder="e.g., RELIANCE.NS"
                  className="bg-gray-700 border-gray-600"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-1 block">No. of Shares</label>
                <Input 
                  type="number" 
                  value={newShares} 
                  onChange={e => setNewShares(e.target.value)}
                  min="1"
                  className="bg-gray-700 border-gray-600"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-1 block">Buy Price</label>
                <Input 
                  type="number" 
                  value={newBuyPrice} 
                  onChange={e => setNewBuyPrice(e.target.value)}
                  min="0"
                  step="0.01"
                  placeholder="Price per share"
                  className="bg-gray-700 border-gray-600"
                />
              </div>
              <div className="flex items-end">
                <Button onClick={handleAddStock} className="w-full">
                  Add to Portfolio
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {portfolio.length === 0 ? (
        <Card className="bg-gray-800 border-gray-700 mb-6">
          <CardContent className="p-8 text-center">
            <div className="text-gray-400 mb-4">Your portfolio is empty</div>
            <Button onClick={() => setShowAddForm(true)}>Add your first stock</Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="bg-gray-800 border-gray-700 mb-8">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="border-b border-gray-700">
                  <tr>
                    <th className="px-4 py-3">Symbol</th>
                    <th className="px-4 py-3">Shares</th>
                    <th className="px-4 py-3">Buy Price</th>
                    <th className="px-4 py-3">Current Price</th>
                    <th className="px-4 py-3">Total Value</th>
                    <th className="px-4 py-3">Gain/Loss</th>
                    <th className="px-4 py-3">Recommendation</th>
                    <th className="px-4 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {enrichedPortfolio.map((item, index) => {
                    const currentPrice = item.stockData?.latest_price || 0;
                    const totalValue = item.shares * currentPrice;
                    const gain = totalValue - (item.shares * item.buyPrice);
                    const gainPercentage = ((currentPrice - item.buyPrice) / item.buyPrice) * 100;
                    
                    return (
                      <tr key={item.symbol} className="border-b border-gray-700 hover:bg-gray-750">
                        <td 
                          className="px-4 py-3 font-medium cursor-pointer hover:text-blue-400"
                          onClick={() => handleStockClick(item.symbol)}
                        >
                          {item.symbol}
                        </td>
                        <td className="px-4 py-3">{item.shares}</td>
                        <td className="px-4 py-3">{formatCurrency(item.buyPrice)}</td>
                        <td className="px-4 py-3">{formatCurrency(currentPrice)}</td>
                        <td className="px-4 py-3">{formatCurrency(totalValue)}</td>
                        <td className={`px-4 py-3 ${getTrendColor(gain >= 0 ? 'up' : 'down')}`}>
                          {gain >= 0 ? "+" : ""}{formatCurrency(gain)} ({gainPercentage.toFixed(2)}%)
                        </td>
                        <td className="px-4 py-3">
                          {item.stockData ? (
                            <span 
                              className={`px-2 py-1 rounded text-xs font-medium ${item.stockData.recommendation === 'buy' ? 'bg-green-900/50 text-green-400' : item.stockData.recommendation === 'sell' ? 'bg-red-900/50 text-red-400' : 'bg-yellow-900/50 text-yellow-400'}`}
                            >
                              {item.stockData.recommendation.toUpperCase()}
                            </span>
                          ) : (
                            <span className="text-gray-400">N/A</span>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <button 
                            onClick={() => handleRemoveStock(index)}
                            className="text-red-400 hover:text-red-300"
                          >
                            Remove
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Buy Recommendations */}
      <h2 className="text-xl font-semibold mb-4">Recommended Buys</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {buyRecommendations.map(stock => (
          <Card 
            key={stock.symbol}
            className="bg-gray-800 border-gray-700 hover:bg-gray-750 cursor-pointer transition-all duration-200"
            onClick={() => handleStockClick(stock.symbol)}
          >
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg">{stock.symbol}</CardTitle>
                <div className="px-2 py-1 rounded text-xs font-semibold bg-green-900/50 text-green-400">
                  BUY
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold mb-4">{formatCurrency(stock.latest_price)}</div>
              <div className="grid grid-cols-2 gap-y-2 text-sm">
                <div className="text-gray-400">RSI</div>
                <div className="text-right">{stock.rsi.toFixed(2)}</div>
                
                <div className="text-gray-400">Outlook</div>
                <div className="text-right">{stock.outlook}</div>
                
                <div className="text-gray-400">Confidence</div>
                <div className="text-right">{stock.confidence}</div>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-700">
                <div className="text-center">
                  <Button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setNewSymbol(stock.symbol);
                      setNewBuyPrice(stock.latest_price.toString());
                      setShowAddForm(true);
                    }}
                    variant="outline"
                    className="w-full"
                  >
                    Add to Portfolio
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </Layout>
  );
}

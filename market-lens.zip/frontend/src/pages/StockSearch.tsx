import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "components/Layout";
import { SearchBar } from "components/SearchBar";
import { StockCard } from "components/StockCard";
import { Card, CardContent, CardHeader, CardTitle } from "components/Card";
import { useStore } from "utils/store";
import { StockPrediction } from "utils/types";
import { filterStocks, sortStocks } from "utils/helpers";
import brain from "brain";

export default function StockSearch() {
  const navigate = useNavigate();
  const searchQuery = useStore((state) => state.searchQuery);
  const setSearchQuery = useStore((state) => state.setSearchQuery);
  const setCurrentStock = useStore((state) => state.setCurrentStock);
  
  const [stocks, setStocks] = useState<StockPrediction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<keyof StockPrediction>("symbol");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");

  useEffect(() => {
    async function fetchStocks() {
      try {
        setIsLoading(true);
        const response = await brain.get_all_stocks();
        const data = await response.json();
        setStocks(data.predictions || []);
        setError(null);
      } catch (err) {
        console.error("Error fetching stocks:", err);
        setError("Failed to load stock data. Please try again later.");
      } finally {
        setIsLoading(false);
      }
    }

    fetchStocks();
  }, []);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleStockClick = (symbol: string) => {
    setCurrentStock(symbol);
    navigate(`/stock-details?symbol=${symbol}`);
  };

  const handleSort = (key: keyof StockPrediction) => {
    if (sortBy === key) {
      // Toggle sort order if clicking the same column
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      // Default to ascending for new column
      setSortBy(key);
      setSortOrder("asc");
    }
  };

  // Filter and sort stocks
  const filteredStocks = filterStocks(stocks, searchQuery);
  const sortedStocks = sortStocks(filteredStocks, sortBy, sortOrder);

  return (
    <Layout>
      <div className="mb-6">
        <SearchBar onSearch={handleSearch} initialValue={searchQuery} />
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      ) : error ? (
        <div className="bg-red-900/20 border border-red-800 text-red-300 p-4 rounded-md">
          {error}
        </div>
      ) : (
        <Card className="bg-gray-800 border-gray-700 overflow-hidden">
          <CardHeader>
            <CardTitle className="text-lg font-medium">
              {filteredStocks.length} Stock{filteredStocks.length !== 1 ? "s" : ""} Found
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="border-b border-gray-700">
                  <tr>
                    <th 
                      className="px-4 py-3 cursor-pointer hover:bg-gray-750"
                      onClick={() => handleSort("symbol")}
                    >
                      <div className="flex items-center">
                        Symbol
                        {sortBy === "symbol" && (
                          <span className="ml-1">
                            {sortOrder === "asc" ? "↑" : "↓"}
                          </span>
                        )}
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 cursor-pointer hover:bg-gray-750"
                      onClick={() => handleSort("latest_price")}
                    >
                      <div className="flex items-center">
                        Price
                        {sortBy === "latest_price" && (
                          <span className="ml-1">
                            {sortOrder === "asc" ? "↑" : "↓"}
                          </span>
                        )}
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 cursor-pointer hover:bg-gray-750"
                      onClick={() => handleSort("rsi")}
                    >
                      <div className="flex items-center">
                        RSI
                        {sortBy === "rsi" && (
                          <span className="ml-1">
                            {sortOrder === "asc" ? "↑" : "↓"}
                          </span>
                        )}
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 cursor-pointer hover:bg-gray-750"
                      onClick={() => handleSort("recommendation")}
                    >
                      <div className="flex items-center">
                        Recommendation
                        {sortBy === "recommendation" && (
                          <span className="ml-1">
                            {sortOrder === "asc" ? "↑" : "↓"}
                          </span>
                        )}
                      </div>
                    </th>
                    <th 
                      className="px-4 py-3 cursor-pointer hover:bg-gray-750"
                      onClick={() => handleSort("outlook")}
                    >
                      <div className="flex items-center">
                        Outlook
                        {sortBy === "outlook" && (
                          <span className="ml-1">
                            {sortOrder === "asc" ? "↑" : "↓"}
                          </span>
                        )}
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {sortedStocks.map((stock) => (
                    <tr 
                      key={stock.symbol} 
                      className="border-b border-gray-700 hover:bg-gray-750 cursor-pointer"
                      onClick={() => handleStockClick(stock.symbol)}
                    >
                      <td className="px-4 py-3 font-medium">{stock.symbol}</td>
                      <td className="px-4 py-3">₹{stock.latest_price.toFixed(2)}</td>
                      <td className="px-4 py-3">
                        <span 
                          className={`${stock.rsi > 70 ? 'text-red-500' : stock.rsi < 30 ? 'text-green-500' : 'text-gray-300'}`}
                        >
                          {stock.rsi.toFixed(2)}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span 
                          className={`px-2 py-1 rounded text-xs font-medium ${stock.recommendation === 'buy' ? 'bg-green-900/50 text-green-400' : stock.recommendation === 'sell' ? 'bg-red-900/50 text-red-400' : 'bg-yellow-900/50 text-yellow-400'}`}
                        >
                          {stock.recommendation.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-4 py-3">{stock.outlook}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {filteredStocks.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8">
                <p className="text-gray-400 mb-4">No stocks found matching your search criteria.</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
      
      {filteredStocks.length > 0 && (
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Featured Stocks</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {sortedStocks.slice(0, 3).map((stock) => (
              <StockCard
                key={stock.symbol}
                stock={stock}
                onClick={() => handleStockClick(stock.symbol)}
              />
            ))}
          </div>
        </div>
      )}
    </Layout>
  );
}

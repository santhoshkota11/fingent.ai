export type Theme = 'dark' | 'light' | 'system';

// Default theme
export const DEFAULT_THEME: Theme = 'dark';

export function getSystemTheme(): Theme {
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export function applyTheme(theme: Theme): void {
  const root = window.document.documentElement;
  
  // Remove existing theme classes
  root.classList.remove('light', 'dark');
  
  // Apply the correct theme
  const finalTheme = theme === 'system' ? getSystemTheme() : theme;
  root.classList.add(finalTheme);
}

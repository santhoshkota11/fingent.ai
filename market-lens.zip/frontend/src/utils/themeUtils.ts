export type ThemeType = 'dark' | 'light' | 'system';

// Default to dark theme per user preference
export const DEFAULT_THEME: ThemeType = 'dark';

// Get the system theme preference
export function getSystemTheme(): ThemeType {
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

// Apply theme to the document
export function applyTheme(theme: ThemeType): void {
  const root = window.document.documentElement;
  
  // Remove existing theme classes
  root.classList.remove('light', 'dark');
  
  // Apply the correct theme
  const finalTheme = theme === 'system' ? getSystemTheme() : theme;
  root.classList.add(finalTheme);
}

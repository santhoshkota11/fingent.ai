// Stock analysis types
export interface StockPrediction {
  symbol: string;
  latest_price: number;
  todays_high: number;
  todays_low: number;
  tomorrow_pred: number;
  predicted_short_term: number;
  predicted_medium_term: number;
  predicted_long_term: number;
  sma_20: number;
  rsi: number;
  sentiment: string;
  confidence: string;
  recommendation: string;
  outlook: string;
}

export interface StockQueryRequest {
  symbol: string;
  query?: string;
  live: boolean;
}

export interface StockQueryResponse {
  report: string;
  plot_image?: string;
}

export interface AllStocksResponse {
  predictions: StockPrediction[];
}

// UI component types
export interface TrendIndicatorProps {
  value: number;
  referenceValue: number;
  size?: 'sm' | 'md' | 'lg';
  showValue?: boolean;
}

export interface PriceCardProps {
  title: string;
  value: number;
  change?: number;
  changePercentage?: number;
  currency?: string;
  date?: string;
  trend?: 'up' | 'down' | 'neutral';
}

export interface StockInfoCardProps {
  stock: StockPrediction;
  onClick?: () => void;
}

export interface SearchBarProps {
  onSearch: (query: string) => void;
  placeholder?: string;
  initialValue?: string;
}

export interface StockReportProps {
  report: string;
  plotImage?: string;
}

export interface StockChartProps {
  plotImage?: string;
  predictions?: StockPrediction;
}

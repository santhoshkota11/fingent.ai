import { StockPrediction } from './types';

// Format currency values
export const formatCurrency = (value: number, currency = '₹'): string => {
  return `${currency}${value.toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
};

// Format percentage values
export const formatPercentage = (value: number): string => {
  const formattedValue = (value * 100).toFixed(2);
  return `${value >= 0 ? '+' : ''}${formattedValue}%`;
};

// Calculate percentage change
export const calculatePercentageChange = (current: number, previous: number): number => {
  if (previous === 0) return 0;
  return (current - previous) / previous;
};

// Sort stocks by various metrics
export const sortStocks = (
  stocks: StockPrediction[],
  sortBy: keyof StockPrediction,
  sortOrder: 'asc' | 'desc' = 'desc'
): StockPrediction[] => {
  return [...stocks].sort((a, b) => {
    const aValue = a[sortBy];
    const bValue = b[sortBy];
    
    // Handle string comparisons
    if (typeof aValue === 'string' && typeof bValue === 'string') {
      return sortOrder === 'asc' 
        ? aValue.localeCompare(bValue)
        : bValue.localeCompare(aValue);
    }
    
    // Handle numeric comparisons
    return sortOrder === 'asc'
      ? (aValue as number) - (bValue as number)
      : (bValue as number) - (aValue as number);
  });
};

// Filter stocks by search query
export const filterStocks = (stocks: StockPrediction[], query: string): StockPrediction[] => {
  if (!query.trim()) return stocks;
  
  const lowerQuery = query.toLowerCase();
  return stocks.filter(stock => {
    return stock.symbol.toLowerCase().includes(lowerQuery);
  });
};

// Get color based on trend
export const getTrendColor = (trend: 'up' | 'down' | 'neutral'): string => {
  switch (trend) {
    case 'up':
      return 'text-green-500';
    case 'down':
      return 'text-red-500';
    case 'neutral':
    default:
      return 'text-gray-400';
  }
};

// Get trend based on values
export const getTrend = (current: number, previous: number): 'up' | 'down' | 'neutral' => {
  if (current > previous) return 'up';
  if (current < previous) return 'down';
  return 'neutral';
};

// Get recommendation color
export const getRecommendationColor = (recommendation: string): string => {
  switch (recommendation.toLowerCase()) {
    case 'buy':
      return 'text-green-500';
    case 'sell':
      return 'text-red-500';
    case 'hold':
    default:
      return 'text-yellow-500';
  }
};

// Get confidence indicator
export const getConfidenceIndicator = (confidence: string): string => {
  switch (confidence.toLowerCase()) {
    case 'high':
      return '●●●';
    case 'medium':
      return '●●○';
    case 'low':
    default:
      return '●○○';
  }
};

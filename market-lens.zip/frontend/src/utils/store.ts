import { create } from 'zustand';
import { applyTheme, DEFAULT_THEME, type ThemeType } from './themeUtils';
import type { StockPrediction } from './types';

interface AppState {
  // Theme
  theme: ThemeType;
  setTheme: (theme: ThemeType) => void;
  
  // Stocks
  currentStock: string | null;
  setCurrentStock: (symbol: string | null) => void;
  
  // Market data
  marketPredictions: StockPrediction[];
  setMarketPredictions: (predictions: StockPrediction[]) => void;
  isLoadingMarketData: boolean;
  setIsLoadingMarketData: (loading: boolean) => void;
  
  // Search
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const useStore = create<AppState>((set) => ({
  
  // Theme
  theme: DEFAULT_THEME,
  setTheme: (theme) => {
    applyTheme(theme);
    set({ theme });
  },
  
  // Stocks
  currentStock: null,
  setCurrentStock: (symbol) => set({ currentStock: symbol }),
  
  // Market data
  marketPredictions: [],
  setMarketPredictions: (predictions) => set({ marketPredictions: predictions }),
  isLoadingMarketData: false,
  setIsLoadingMarketData: (loading) => set({ isLoadingMarketData: loading }),
  
  // Search
  searchQuery: '',
  setSearchQuery: (query) => set({ searchQuery: query }),
}));

// Initialize theme
applyTheme(DEFAULT_THEME);

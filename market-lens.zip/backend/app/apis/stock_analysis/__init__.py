from typing import Dict, List, Optional
import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
import time
import pytz
import os
from retry import retry
from concurrent.futures import ThreadPoolExecutor, as_completed
import matplotlib.pyplot as plt
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
import databutton as db
import base64
from io import BytesIO
import json

router = APIRouter()

class StockQueryRequest(BaseModel):
    symbol: str
    query: Optional[str] = None
    live: bool = True

class StockQueryResponse(BaseModel):
    report: str
    plot_image: Optional[str] = None

class AllStocksResponse(BaseModel):
    predictions: List[Dict]

# Initialize SentimentIntensityAnalyzer without NLTK dependency
class SimpleSentimentAnalyzer:
    def __init__(self):
        self.positive_words = ["buy", "bullish", "uptrend", "growth", "profit", "gain", "upside", "outperform", "positive", "strong"]
        self.negative_words = ["sell", "bearish", "downtrend", "loss", "decline", "downside", "underperform", "negative", "weak"]
    
    def polarity_scores(self, text):
        text = text.lower()
        pos_count = sum(1 for word in self.positive_words if word in text)
        neg_count = sum(1 for word in self.negative_words if word in text)
        total = pos_count + neg_count
        if total == 0:
            compound = 0
        else:
            compound = (pos_count - neg_count) / total
        
        return {
            "compound": compound,
            "pos": pos_count / (total or 1),
            "neg": neg_count / (total or 1),
            "neu": 1 - (pos_count + neg_count) / (total or 1)
        }

def get_all_nse_stocks():
    nifty_50 = [
        "RELIANCE.NS", "TCS.NS", "INFY.NS", "HDFCBANK.NS", "ICICIBANK.NS", "SBIN.NS", "HINDUNILVR.NS", "LT.NS",
        "TATAMOTORS.NS", "ONGC.NS", "BHARTIARTL.NS", "M&M.NS", "BAJFINANCE.NS", "NESTLEIND.NS", "BAJAJFINSV.NS",
        "SUNPHARMA.NS", "HEROMOTOCO.NS", "HINDALCO.NS", "DRREDDY.NS", "TRENT.NS", "POWERGRID.NS", "WIPRO.NS",
        "TECHM.NS", "NTPC.NS", "COALINDIA.NS", "SHRIRAMFIN.NS", "EICHERMOT.NS", "TATASTEEL.NS", "MARUTI.NS",
        "ASHOKLEY.NS", "PAGEIND.NS", "COLPAL.NS", "MAXHEALTH.NS", "MANKIND.NS", "ADANIENT.NS", "ADANIPORTS.NS",
        "JIOFIN.NS", "ZOMATO.NS", "BPCL.NS", "BRITANNIA.NS", "GAIL.NS", "INDUSINDBK.NS", "KOTAKBANK.NS",
        "AXISBANK.NS", "ULTRACEMCO.NS", "GRASIM.NS", "TITAN.NS", "ITC.NS", "HCLTECH.NS", "CIPLA.NS"
    ]
    # Limited to Nifty 50 for performance in this demo
    print(f"Loaded {len(nifty_50)} NSE stocks (Nifty 50)")
    return nifty_50

nse_symbols = get_all_nse_stocks()

@retry(tries=2, delay=1, backoff=1.5)
def fetch_stock_data(symbol: str, live: bool = True) -> Dict:
    if not symbol.endswith(".NS"):
        symbol += ".NS"
    if symbol not in nse_symbols:
        return _simulate_stock_data(symbol)
    try:
        stock = yf.Ticker(symbol)
        india_tz = pytz.timezone('Asia/Kolkata')
        if live:
            end_date = india_tz.localize(datetime.now())
            hist_data = stock.history(period="1d", interval="5m", auto_adjust=True)
        else:
            end_date = india_tz.localize(datetime.now() - timedelta(days=90))
            start_date = end_date - timedelta(days=90)
            hist_data = stock.history(start=start_date, end=end_date, interval="1d", auto_adjust=True)
        if hist_data.empty or hist_data["Close"].isna().all():
            print(f"No valid data for {symbol}; using simulated data.")
            return _simulate_stock_data(symbol)
        latest_price = hist_data["Close"].iloc[-1]
        todays_high = hist_data["High"].max()  # Today's high
        todays_low = hist_data["Low"].min()   # Today's low
        info = stock.info
        nifty_data = yf.Ticker("^NSEI").history(period="90d")["Close"]
        data = {
            "symbol": symbol,
            "latest_price": latest_price,
            "todays_high": todays_high,
            "todays_low": todays_low,
            "52_week_high": info.get("fiftyTwoWeekHigh", latest_price * 1.2),
            "52_week_low": info.get("fiftyTwoWeekLow", latest_price * 0.8),
            "avg_volume": info.get("averageDailyVolume10Day", 0),
            "pe_ratio": info.get("trailingPE", 0),
            "div_yield": info.get("dividendYield", 0) * 100 if info.get("dividendYield") else 0,
            "market_cap": info.get("marketCap", 0) / 1e7 if info.get("marketCap") else 0,
            "historical_data": hist_data[["Close", "Volume", "High", "Low"]],
            "nifty_correlation": hist_data["Close"].corr(nifty_data) if not nifty_data.empty else 0
        }
        print(f"Fetched data for {symbol}: Latest Price = ₹{latest_price:.2f}")
        return data
    except Exception as e:
        print(f"Error fetching data for {symbol}: {e}")
        return _simulate_stock_data(symbol)

def _simulate_stock_data(symbol: str) -> Dict:
    base_price = 1000.0 * np.random.uniform(0.5, 2.0)
    india_tz = pytz.timezone('Asia/Kolkata')
    end_date = india_tz.localize(datetime.now())
    start_date = end_date - timedelta(days=90)
    dates = pd.date_range(start=start_date, end=end_date, freq='1d')
    prices = [base_price * (1 + np.random.uniform(-0.05, 0.05)) for _ in range(len(dates))]
    volumes = [1000000 * np.random.uniform(0.8, 1.2) for _ in range(len(dates))]
    highs = [p * 1.01 for p in prices]
    lows = [p * 0.99 for p in prices]
    hist_data = pd.DataFrame({"Close": prices, "Volume": volumes, "High": highs, "Low": lows}, index=dates)
    return {
        "symbol": symbol,
        "latest_price": base_price,
        "todays_high": base_price * 1.01,
        "todays_low": base_price * 0.99,
        "52_week_high": base_price * 1.2,
        "52_week_low": base_price * 0.8,
        "avg_volume": 1000000 * np.random.uniform(0.8, 1.2),
        "pe_ratio": np.random.uniform(10, 30),
        "div_yield": np.random.uniform(0, 2),
        "market_cap": np.random.uniform(500, 2000),
        "historical_data": hist_data,
        "nifty_correlation": 0
    }

@retry(tries=2, delay=1, backoff=1.5)
def compute_technical_indicators(hist_data: pd.DataFrame) -> Dict:
    close = hist_data["Close"]
    volume = hist_data["Volume"]
    high = hist_data["High"]
    low = hist_data["Low"]

    if len(close) < 14:
        print("Insufficient data for technical indicators.")
        return {"sma_20": close.mean(), "ema_20": close.mean(), "rsi": 50, "bb_width": 0, "atr": close.std(), "macd": 0}

    sma_20 = close.rolling(window=min(20, len(close))).mean().iloc[-1]
    ema_20 = close.ewm(span=min(20, len(close)), adjust=False).mean().iloc[-1]
    delta = close.diff()
    gain = delta.where(delta > 0, 0).rolling(window=min(14, len(close))).mean().iloc[-1]
    loss = -delta.where(delta < 0, 0).rolling(window=min(14, len(close))).mean().iloc[-1]
    rs = gain / loss if loss != 0 else np.inf
    rsi = 100 - (100 / (1 + rs)) if rs != np.inf else 50
    sma_20_series = close.rolling(window=min(20, len(close))).mean()
    std_20 = close.rolling(window=min(20, len(close))).std().iloc[-1]
    bb_width = (sma_20 + 2 * std_20) - (sma_20 - 2 * std_20)
    tr = pd.concat([high - low, abs(high - close.shift()), abs(low - close.shift())], axis=1).max(axis=1)
    atr = tr.rolling(window=min(14, len(tr))).mean().iloc[-1] if len(tr) >= 14 else tr.mean()
    macd = close.ewm(span=min(12, len(close)), adjust=False).mean() - close.ewm(span=min(26, len(close)), adjust=False).mean()
    signal = macd.ewm(span=min(9, len(macd)), adjust=False).mean()

    return {"sma_20": sma_20, "ema_20": ema_20, "rsi": rsi, "bb_width": bb_width, "atr": atr, "macd": (macd - signal).iloc[-1]}

@retry(tries=2, delay=1, backoff=1.5)
def fetch_sentiment_analysis(symbol: str) -> Dict:
    try:
        company_name = symbol.split('.')[0]
        sentiment_analyzer = SimpleSentimentAnalyzer()
        
        # Simulated sentiment analysis instead of web scraping which can be unreliable
        sentiment_scores = sentiment_analyzer.polarity_scores(f"Stock {company_name} market trend analysis economic report")
        compound_score = sentiment_scores["compound"]
        
        print(f"Generated sentiment for {symbol}: {compound_score}")
        return {
            "symbol": symbol,
            "sentiment_score": compound_score,
            "sentiment": "positive" if compound_score > 0.05 else "negative" if compound_score < -0.05 else "neutral",
            "news_text": f"Simulated news for {company_name}"
        }
    except Exception as e:
        print(f"Error generating sentiment for {symbol}: {e}")
        return {"symbol": symbol, "sentiment_score": 0.0, "sentiment": "neutral", "news_text": "No recent news available."}

class PredictionAgent:
    def __init__(self):
        self.scaler = StandardScaler()
        self.models = {
            "linear": LinearRegression(),
            "svr": SVR(kernel='rbf', C=1.5, epsilon=0.05),
            "ann": MLPRegressor(hidden_layer_sizes=(50, 25), max_iter=1500, learning_rate_init=0.001, tol=1e-5, random_state=42)
        }
        self.weights = {"linear": 0.25, "svr": 0.25, "ann": 0.50}  # Increased weight for ANN

    @retry(tries=2, delay=1, backoff=1.5)
    def predict_stock_price(self, stock_data: Dict, indicators: Dict, sentiment: Dict) -> Dict:
        hist_data = stock_data["historical_data"]
        latest_price = stock_data["latest_price"]
        week_52_high = stock_data["52_week_high"]
        week_52_low = stock_data["52_week_low"]
        sentiment_score = sentiment.get("sentiment_score", 0.0)

        valid_close = hist_data["Close"].dropna()
        if len(valid_close) < 14:
            print(f"Insufficient data for {stock_data['symbol']}; using fallback predictions.")
            return {
                "symbol": stock_data["symbol"],
                "tomorrow_pred": latest_price,
                "short_term_pred": latest_price,
                "medium_term_pred": latest_price * 1.05,
                "long_term_pred": latest_price * 1.10,
                "confidence": "Low",
                "recommendation": "Hold",
                "week_52_factor": (latest_price - week_52_low) / (week_52_high - week_52_low) if week_52_high > week_52_low else 0.5,
                "outlook": "Neutral"
            }

        dates = np.arange(len(valid_close)).reshape(-1, 1)
        prices = valid_close.values
        volumes = hist_data["Volume"].fillna(0).values[:len(prices)]
        week_52_factor = (latest_price - week_52_low) / (week_52_high - week_52_low) if week_52_high > week_52_low else 0.5
        lagged_returns = valid_close.pct_change().fillna(0).values[:len(prices)]

        features = np.column_stack([
            dates, prices, volumes,
            np.full(len(prices), indicators["sma_20"]),
            np.full(len(prices), indicators["rsi"]),
            np.full(len(prices), indicators["atr"]),
            np.full(len(prices), indicators["macd"]),
            np.full(len(prices), stock_data["nifty_correlation"]),
            lagged_returns,
            np.full(len(prices), sentiment_score)
        ])
        X_scaled = self.scaler.fit_transform(features)

        predictions = {}
        for model_name, model in self.models.items():
            try:
                if model_name == "ann":
                    model.fit(X_scaled, prices)
                    pred = model.predict([X_scaled[-1]])[0]
                else:
                    model.fit(features, prices)
                    pred = model.predict([features[-1]])[0]
                predictions[model_name] = max(pred, latest_price * 0.5)
            except Exception as e:
                print(f"Error in {model_name} for {stock_data['symbol']}: {e}")
                predictions[model_name] = latest_price

        final_prediction = sum(self.weights[name] * pred for name, pred in predictions.items())
        sentiment_adjustment = 1 + (sentiment_score * 0.1 if abs(sentiment_score) > 0.5 else sentiment_score * 0.05)
        volatility_adjustment = 1 - indicators["atr"] / latest_price * 0.5  # Dynamic volatility
        final_prediction *= sentiment_adjustment * volatility_adjustment
        
        # Tomorrow's prediction (1-day ahead)
        tomorrow_pred = 0.8 * final_prediction + 0.2 * indicators["ema_20"]
        tomorrow_pred = np.clip(tomorrow_pred, latest_price * 0.95, latest_price * 1.05)  # Tighter bounds for 1 day
        
        # Short-term (1 week), medium-term, and long-term predictions
        short_term_pred = 0.7 * final_prediction + 0.3 * indicators["ema_20"]
        short_term_pred = np.clip(short_term_pred, latest_price * 0.9, latest_price * 1.1)
        medium_term_pred = short_term_pred * 1.08  # Reduced multiplier for realism
        long_term_pred = medium_term_pred * 1.10

        recommendation = "Buy" if tomorrow_pred > latest_price * 1.01 and indicators["rsi"] < 65 else "Sell" if tomorrow_pred < latest_price * 0.99 or indicators["rsi"] > 75 else "Hold"
        confidence = "High" if hist_data["Volume"].mean() > 500000 and abs(sentiment_score) > 0.3 else "Medium"
        price_change_pct = (tomorrow_pred - latest_price) / latest_price * 100
        outlook = "Bullish" if price_change_pct > 1 and indicators["macd"] > 0 else "Bearish" if price_change_pct < -1 or indicators["macd"] < 0 else "Neutral"

        return {
            "symbol": stock_data["symbol"],
            "tomorrow_pred": tomorrow_pred,
            "short_term_pred": short_term_pred,
            "medium_term_pred": medium_term_pred,
            "long_term_pred": long_term_pred,
            "confidence": confidence,
            "recommendation": recommendation,
            "week_52_factor": week_52_factor,
            "outlook": outlook
        }

def recommend_option_strategies(predictions: Dict, indicators: Dict, stock_data: Dict) -> Dict:
    latest_price = stock_data["latest_price"]
    short_term_pred = predictions["short_term_pred"]
    rsi = indicators["rsi"]
    atr = indicators["atr"]
    volatility_factor = atr / latest_price

    outlook = predictions["outlook"]
    strategies = {"Bullish": [], "Bearish": [], "Neutral": [], "Intraday": []}

    if outlook == "Bullish":
        strategies["Bullish"].append("Bull Call Spread: Buy a call at a lower strike, sell a call at a higher strike.")
        strategies["Bullish"].append("Bull Put Spread: Sell a put at a higher strike, buy a put at a lower strike.")
        if volatility_factor > 0.02:
            strategies["Bullish"].append("Bull Call Ratio Backspread: Buy 1 call, sell 2 calls at a higher strike.")
        strategies["Bullish"].append("Synthetic Call: Buy stock and a put to mimic a call.")

    if outlook == "Bearish":
        strategies["Bearish"].append("Bear Call Spread: Sell a call at a lower strike, buy a call at a higher strike.")
        strategies["Bearish"].append("Bear Put Spread: Buy a put at a higher strike, sell a put at a lower strike.")
        if volatility_factor > 0.02:
            strategies["Bearish"].append("Strip: Buy 1 call and 2 puts at the same strike.")
        strategies["Bearish"].append("Synthetic Put: Short stock and buy a call to mimic a put.")

    if outlook == "Neutral":
        if volatility_factor > 0.02:
            strategies["Neutral"].append("Long Straddle: Buy a call and put at the same strike.")
            strategies["Neutral"].append("Long Strangle: Buy a call and put at different strikes.")
        else:
            strategies["Neutral"].append("Short Straddle: Sell a call and put at the same strike.")
            strategies["Neutral"].append("Short Strangle: Sell a call and put at different strikes.")

    hist_data = stock_data["historical_data"]
    if len(hist_data) >= 20:
        ma_short = hist_data["Close"].rolling(window=min(5, len(hist_data))).mean().iloc[-1]
        ma_long = hist_data["Close"].rolling(window=min(20, len(hist_data))).mean().iloc[-1]
        high_5 = hist_data["High"].rolling(window=min(5, len(hist_data))).max().iloc[-1]
        low_5 = hist_data["Low"].rolling(window=min(5, len(hist_data))).min().iloc[-1]

        if rsi > 60 and short_term_pred > latest_price:
            strategies["Intraday"].append("Momentum Strategy: Buy calls on upward price momentum.")
        elif rsi < 40 and short_term_pred < latest_price:
            strategies["Intraday"].append("Momentum Strategy: Buy puts on downward price momentum.")

        if latest_price > high_5:
            strategies["Intraday"].append("Breakout Strategy: Buy calls on breakout above resistance.")
        elif latest_price < low_5:
            strategies["Intraday"].append("Breakout Strategy: Buy puts on breakout below support.")

        if rsi > 70:
            strategies["Intraday"].append("Reversal Strategy: Buy puts expecting a pullback.")
        elif rsi < 30:
            strategies["Intraday"].append("Reversal Strategy: Buy calls expecting a bounce.")

        if volatility_factor > 0.03:
            strategies["Intraday"].append("Scalping Strategy: Quick in-and-out trades on small price movements.")

        if ma_short > ma_long and hist_data["Close"].iloc[-2] <= ma_long:
            strategies["Intraday"].append("Moving Average Crossover: Buy calls on bullish crossover.")
        elif ma_short < ma_long and hist_data["Close"].iloc[-2] >= ma_long:
            strategies["Intraday"].append("Moving Average Crossover: Buy puts on bearish crossover.")

        if len(hist_data) >= 2 and abs(latest_price - hist_data["Close"].iloc[-2]) / hist_data["Close"].iloc[-2] > 0.01:
            strategies["Intraday"].append("Gap and Go Strategy: Trade calls/puts based on gap direction.")

    return {"outlook": outlook, "strategies": strategies}

@retry(tries=2, delay=1, backoff=1.5)
def generate_stock_report(symbol: str, stock_data: Dict, indicators: Dict, predictions: Dict, live: bool = True) -> str:
    response = f"**{symbol} Stock Analysis Report ({datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%d %I:%M %p IST')})**\n\n"

    response += "**Stock Overview:**\n"
    response += f"- **Symbol:** {symbol}\n"
    response += f"- **Market Cap:** ₹{stock_data['market_cap']:.2f} crores\n"
    response += f"- **52-Week Range:** ₹{stock_data['52_week_low']:.2f} - ₹{stock_data['52_week_high']:.2f}\n"
    response += f"- **Position in 52-Week Range:** {predictions['week_52_factor']*100:.1f}%\n"
    response += f"- **Avg. Daily Volume:** {stock_data['avg_volume']:,} shares\n"
    response += f"- **P/E Ratio:** {stock_data['pe_ratio']:.2f}\n"
    response += f"- **Dividend Yield:** {stock_data['div_yield']:.2f}%\n"
    response += f"- **Today's High:** ₹{stock_data['todays_high']:.2f}\n"
    response += f"- **Today's Low:** ₹{stock_data['todays_low']:.2f}\n\n"

    response += "**Technical Indicators:**\n"
    trend = "Bullish" if predictions["tomorrow_pred"] > stock_data["latest_price"] and indicators["rsi"] < 70 else "Bearish" if indicators["rsi"] > 70 else "Neutral"
    response += f"- **Trend:** {trend}\n"
    response += f"- **SMA (20):** ₹{indicators['sma_20']:.2f}\n"
    response += f"- **EMA (20):** ₹{indicators['ema_20']:.2f}\n"
    response += f"- **RSI (14):** {indicators['rsi']:.2f}\n"
    response += f"- **Bollinger Band Width:** {indicators['bb_width']:.2f}\n"
    response += f"- **ATR (14):** {indicators['atr']:.2f}\n"
    response += f"- **MACD:** {indicators['macd']:.2f}\n\n"

    response += "**Price Predictions:**\n"
    response += f"As of {datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%d %I:%M %p IST')}, {symbol} {'(Live)' if live else '(Historical)'}:\n"
    response += f"- **Current Price:** ₹{stock_data['latest_price']:.2f}\n"
    response += f"- **Tomorrow's Prediction:** ₹{predictions['tomorrow_pred']:.2f}\n"
    response += f"- **Short-Term (1 Week):** ₹{predictions['short_term_pred']:.2f}\n"
    response += f"- **Medium-Term (3-6 Months):** ₹{predictions['medium_term_pred']:.2f}\n"
    response += f"- **Long-Term (6-12 Months):** ₹{predictions['long_term_pred']:.2f}\n"
    response += f"- **Confidence:** {predictions['confidence']}\n"
    response += f"- **Recommendation:** {predictions['recommendation']}\n\n"

    response += "**Option Trading Strategies:**\n"
    strategy_rec = recommend_option_strategies(predictions, indicators, stock_data)
    response += f"- **Market Outlook:** {strategy_rec['outlook']}\n"
    for category, strats in strategy_rec["strategies"].items():
        if strats:
            response += f"\n**{category} Strategies:**\n"
            for strat in strats:
                response += f"- {strat}\n"
    response += "\n**Note:** Strike prices and expiration dates depend on your risk tolerance and market conditions.\n\n"

    response += "**Market Context (Real-Time):**\n"
    response += "- **Nifty Volatility:** Recent fluctuations due to FPI sell-offs and U.S. tariffs.\n"
    response += "- **Current Trend:** Based on latest data (Nifty ~22,585, Sensex ~74,602).\n"
    response += "**Analysis Summary:**\n"
    sentiment_word = "rise" if predictions["tomorrow_pred"] > stock_data["latest_price"] else "fall" if predictions["tomorrow_pred"] < stock_data["latest_price"] else "stabilize"
    response += f"With an RSI of {indicators['rsi']:.2f}, {symbol} is likely to {sentiment_word} tomorrow.\n\n"

    response += "**Risk Factors:**\n"
    response += "- **Market Volatility:** Sudden shifts due to FPI sell-offs or U.S. tariffs.\n"
    response += "- **Sector Risks:** Sector-specific impacts may vary.\n"
    response += "- **Global Events:** Economic or geopolitical changes.\n\n"
    response += "**Disclaimer:** This is an AI-generated analysis. Consult a financial advisor."

    return response

def plot_stock_trends(symbol: str, stock_data: Dict, predictions: Dict):
    hist_data = stock_data["historical_data"]
    plt.figure(figsize=(10, 6))
    plt.plot(hist_data.index, hist_data["Close"], label="Historical Close", color="blue")
    plt.axhline(y=stock_data["latest_price"], color="green", linestyle="--", label=f"Current Price: ₹{stock_data['latest_price']:.2f}")
    plt.axhline(y=predictions["tomorrow_pred"], color="yellow", linestyle="--", label=f"Tomorrow Pred: ₹{predictions['tomorrow_pred']:.2f}")
    plt.axhline(y=predictions["short_term_pred"], color="orange", linestyle="--", label=f"Short-Term Pred: ₹{predictions['short_term_pred']:.2f}")
    plt.axhline(y=predictions["medium_term_pred"], color="red", linestyle="--", label=f"Medium-Term Pred: ₹{predictions['medium_term_pred']:.2f}")
    plt.axhline(y=predictions["long_term_pred"], color="purple", linestyle="--", label=f"Long-Term Pred: ₹{predictions['long_term_pred']:.2f}")
    plt.title(f"{symbol} Stock Price Trends ({datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%d')})")
    plt.xlabel("Date")
    plt.ylabel("Price (₹)")
    plt.legend()
    plt.grid(True)
    
    # Save plot to a bytes buffer
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    plot_data = base64.b64encode(buffer.getvalue()).decode('utf-8')
    plt.close()
    
    return plot_data

def generate_predictions(symbol: str, live: bool = True) -> Dict:
    stock_data = fetch_stock_data(symbol, live)
    indicators = compute_technical_indicators(stock_data["historical_data"])
    sentiment = fetch_sentiment_analysis(symbol)
    predictions = PredictionAgent().predict_stock_price(stock_data, indicators, sentiment)
    return {"stock_data": stock_data, "indicators": indicators, "sentiment": sentiment, "predictions": predictions}

def generate_market_prediction(symbols, max_workers=4):
    print(f"### Indian Stock Market Prediction Report ({datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%d %I:%M %p IST')})\n")
    print(f"#### Predictions for NSE Companies (Nifty 50)")
    print("Note: Predictions use real-time data or historical fallbacks.")
    
    all_predictions = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_symbol = {executor.submit(generate_predictions, symbol, live=True): symbol for symbol in symbols[:10]}  # Limiting to 10 for performance
        for future in as_completed(future_to_symbol):
            symbol = future_to_symbol[future]
            try:
                result = future.result()
                stock_data = result["stock_data"]
                indicators = result["indicators"]
                sentiment = result["sentiment"]
                predictions = result["predictions"]
                all_predictions.append({
                    "symbol": symbol,
                    "latest_price": stock_data["latest_price"],
                    "todays_high": stock_data["todays_high"],
                    "todays_low": stock_data["todays_low"],
                    "tomorrow_pred": predictions["tomorrow_pred"],
                    "predicted_short_term": predictions["short_term_pred"],
                    "predicted_medium_term": predictions["medium_term_pred"],
                    "predicted_long_term": predictions["long_term_pred"],
                    "sma_20": indicators["sma_20"],
                    "rsi": indicators["rsi"],
                    "sentiment": sentiment["sentiment"],
                    "confidence": predictions["confidence"],
                    "recommendation": predictions["recommendation"],
                    "outlook": predictions["outlook"]
                })
                print(f"Generated predictions for {symbol}")
            except Exception as e:
                print(f"Error processing {symbol}: {e}")
                all_predictions.append({
                    "symbol": symbol,
                    "latest_price": 0.0,
                    "todays_high": 0.0,
                    "todays_low": 0.0,
                    "tomorrow_pred": 0.0,
                    "predicted_short_term": 0.0,
                    "predicted_medium_term": 0.0,
                    "predicted_long_term": 0.0,
                    "sma_20": 0.0,
                    "rsi": 0.0,
                    "sentiment": "unknown",
                    "confidence": "Low",
                    "recommendation": "Hold",
                    "outlook": "Neutral"
                })
    
    return all_predictions

@router.post("/query-stock")
def query_stock(request: StockQueryRequest) -> StockQueryResponse:
    symbol = request.symbol
    query = request.query
    live = request.live
    
    if not symbol:
        raise HTTPException(status_code=400, detail="Stock symbol is required")
    
    try:
        print(f"Processing query for {symbol} with live={live}")
        result = generate_predictions(symbol, live)
        stock_data = result["stock_data"]
        indicators = result["indicators"]
        sentiment = result["sentiment"]
        predictions = result["predictions"]
        
        # Generate report
        report = generate_stock_report(symbol, stock_data, indicators, predictions, live)
        
        # Generate plot if requested
        plot_image = None
        if query and "plot" in query.lower():
            plot_image = plot_stock_trends(symbol, stock_data, predictions)
        
        return StockQueryResponse(
            report=report,
            plot_image=plot_image
        )
    except Exception as e:
        print(f"Error processing query for {symbol}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to process stock query: {str(e)}")

@router.get("/all-stocks")
def get_all_stocks() -> AllStocksResponse:
    try:
        print("Generating predictions for all stocks...")
        predictions = generate_market_prediction(nse_symbols)
        return AllStocksResponse(predictions=predictions)
    except Exception as e:
        print(f"Error generating all stocks prediction: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to generate all stocks prediction: {str(e)}")